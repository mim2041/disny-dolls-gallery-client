# The Website is a Toy Selling website. The functionalities and information are given below:
* In the Home page there I have given information about the website. There I have added some relevant sections.
* I have added Blog page where I have answered some questions.
* There is a All Toys page where All the toys information is shown in a tabular form.
* One can view details of the toy's after login.
* I have added private route to protect some pages from casual user. Without login, none can see the pages.
* There is also authentication systems. A user can sign up and login to see the best features of the website.
* A user can add new toys, delete them and update the toy's information. 
* In My Toys page, A user can only see the toy's that he/she has added. They can not see other user's added toy's there.

## Live Link : https://disney-dolls-gallery.web.app/